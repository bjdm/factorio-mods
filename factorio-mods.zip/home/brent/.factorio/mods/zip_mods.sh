zip --symlinks -r factorio-mods.zip ./
